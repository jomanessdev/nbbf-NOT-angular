<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'Enter your twitter app consumer key here');
    define('CONSUMER_SECRET', 'Enter your twitter app consumer secret here');

    // User Access Token
    define('ACCESS_TOKEN', 'Enter your twitter app access token here');
    define('ACCESS_SECRET', 'Enter your twitter app access secret here');